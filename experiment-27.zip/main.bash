#!/bin/sh 
echo "enter the number"
read a 
square=$((a*a))
echo "square of "$a"="$square